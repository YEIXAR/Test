<?php

namespace UCR\FirstBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UCRFirstBundle extends Bundle
{
}
